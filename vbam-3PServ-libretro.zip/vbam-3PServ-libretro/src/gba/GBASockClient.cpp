#ifndef NO_LINK

#endif // NO_LINK
