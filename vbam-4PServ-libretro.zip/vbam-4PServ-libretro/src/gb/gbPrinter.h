#ifndef GBPRINTER_H
#define GBPRINTER_H

#include "../System.h"

u8 gbPrinterSend(u8 b);

#endif // GBPRINTER_H
